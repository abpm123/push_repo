package com.cg.beans;

public enum LicenseType {

	FREEWARE,

	SHAREWARE
}